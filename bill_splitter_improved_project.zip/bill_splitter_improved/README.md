# Bill Splitter — Improved Version

## Run
1. Install Python 3.10 or newer.
2. Open this folder in VS Code.
3. Optional charts dependency: `py -m pip install -r requirements.txt`
4. Start the application: `py proj.py`

The application stores data in `data/` and exports reports to `exports/`.

## Run checks
`py -m unittest -v`

## Improvements
- Stronger validation for amounts, percentages, categories, participants, timestamps, and saved calculations.
- Rejects NaN/infinity and inconsistent stored totals.
- CSV import supports UTF-8 BOM and validates each row.
- CSV export neutralizes spreadsheet formula injection in text cells.
- Duplicate participant names and duplicate stored bill IDs are handled safely.
- Includes regression tests for calculations and validation.

The existing CLI workflow and JSON/CSV data format are retained.
