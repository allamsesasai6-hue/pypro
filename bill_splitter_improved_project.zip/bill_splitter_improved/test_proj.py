import math
import tempfile
import unittest
from pathlib import Path

import proj


class BillSplitterTests(unittest.TestCase):
    def test_basic_split_and_tip(self):
        bill = proj.compute_bill_split(
            "Dinner", "Food & Dining", 1000, 10, ["Asha", "Ravi"], 0
        )
        self.assertEqual(bill.total_amount, 1100.0)
        self.assertEqual(bill.per_person_share, 550.0)

    def test_rounds_share_up_to_paise(self):
        bill = proj.compute_bill_split(
            "Cab", "Travel & Cab", 100, 0, ["A", "B", "C"], 0
        )
        self.assertEqual(bill.per_person_share, 33.34)

    def test_rejects_non_finite_amount(self):
        with self.assertRaises(ValueError):
            proj.compute_bill_split(
                "Dinner", "Food & Dining", math.inf, 0, ["A", "B"], 0
            )

    def test_rejects_invalid_tip(self):
        with self.assertRaises(ValueError):
            proj.compute_bill_split(
                "Dinner", "Food & Dining", 100, 101, ["A", "B"], 0
            )

    def test_rejects_duplicate_or_insufficient_people(self):
        with self.assertRaises(ValueError):
            proj.compute_bill_split(
                "Dinner", "Food & Dining", 100, 0, ["Asha", " asha "], 0
            )

    def test_rejects_invalid_category(self):
        with self.assertRaises(ValueError):
            proj.compute_bill_split("Dinner", "Unknown", 100, 0, ["A", "B"], 0)

    def test_record_round_trip_validation(self):
        bill = proj.compute_bill_split(
            "Lunch", "Food & Dining", 500, 5, ["A", "B"], 0
        )
        parsed = proj.validate_record_dict(proj.asdict(bill))
        self.assertIsNotNone(parsed)
        self.assertEqual(parsed.total_amount, bill.total_amount)

    def test_rejects_inconsistent_saved_total(self):
        bill = proj.compute_bill_split(
            "Lunch", "Food & Dining", 500, 5, ["A", "B"], 0
        )
        raw = proj.asdict(bill)
        raw["total_amount"] = 1
        self.assertIsNone(proj.validate_record_dict(raw))

    def test_seed_data_is_valid(self):
        for record in proj.get_seed_records():
            self.assertIsNotNone(proj.validate_record_dict(proj.asdict(record)))


if __name__ == "__main__":
    unittest.main(verbosity=2)
